package com.mycompany.colas;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;
import java.util.PriorityQueue;

public class Colas {

    public static void main(String[] args) {
        System.out.println("Ejercicios Colas con librerias de JAVA\n");
        colasimple();
        colacircular();
        colaprioridad();
        colasdoble();
    }
    
    static void colasimple(){
        System.out.println("Ejercicios Colas simple: primero en llegar primero en salir (FIFO)\n");
        Queue<String> java = new ArrayDeque<>();
        java.offer("ANA");
        java.offer("VIVIANA");
        java.offer("LEINER");
        System.out.println("java: " + java.poll() + ", " + java.poll() + "\n" );
    }
    
    static void colacircular(){
        System.out.println("Ejercicios Colas circular: Reutilizar los espacios del arreglo\n");
        Queue<String> java = new ArrayDeque<>();
        java.offer("ANA");
        java.offer("VIVIANA");
        java.offer("LEINER");
        System.out.println("SALE: " + java.poll());
        java.offer("FABIO");
        System.out.println("java: " + java.poll() + ", " + java.poll() + ", " + java.poll() + "\n" );
    }
    
    static void colaprioridad(){
        System.out.println("Ejercicios Colas prioridad: el menor numero atiende al primero\n");
        Queue<Integer> java = new PriorityQueue<>();
        java.offer(5);
        java.offer(2);
        java.offer(3);
        System.out.println("java: " + java.poll() + ", " + java.poll() + ", " + java.poll() + "\n" );
    }
    
    static void colasdoble(){
        System.out.println("Ejercicios Colas DOBLE : PERMITE USAR AMBOS EXTREMOS\n");
        Deque<String> java = new ArrayDeque<>();
        java.offerLast("ANA");
        java.offerLast("VIVIANA");
        java.offerFirst("LEINER");
        System.out.println("java: Sale del inicio " + java.pollFirst() + ", Sale del final " + java.pollLast());
    }
}
